# CLiP Wallet App

This is a React Native (Expo) app for CLiP Acceptance, including:
- Wallet Screen
- Fundraising Tracker
- Emergency alert integration

## Getting Started
1. Install dependencies: `npm install`
2. Start Expo: `npx expo start`
