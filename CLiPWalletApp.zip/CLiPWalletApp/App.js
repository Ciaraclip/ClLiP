import React from 'react';
import WalletScreen from './screens/WalletScreen';

export default function App() {
  return <WalletScreen />;
}
